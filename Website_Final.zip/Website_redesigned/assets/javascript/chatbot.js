document.addEventListener("DOMContentLoaded", () => {
  /* ================= CONFIG ================= */
  const BOT_NAME = "PushpakBot 🤖";

  const toggleBtn = document.getElementById("chatbot-toggle");
  const chatBox = document.getElementById("chatbot");
  const closeBtn = document.getElementById("chat-close");
  const themeToggle = document.getElementById("theme-toggle");

  const chatBody = document.getElementById("chat-body");
  const chatInput = document.getElementById("chat-input");
  const chatSend = document.getElementById("chat-send");
  const pingSound = document.getElementById("ping");

  let lastTopic = null;
  let chatOpenedOnce = false;

  /* Cache full section content */
  const sectionCache = {};

  /* ================= OPEN / CLOSE ================= */
  toggleBtn.addEventListener("click", () => {
    chatBox.style.display = "flex";
    toggleBtn.style.display = "none";

    if (!chatOpenedOnce) {
      chatOpenedOnce = true;
      welcomeMessage();
    }
  });

  closeBtn.addEventListener("click", () => {
    chatBox.style.display = "none";
    toggleBtn.style.display = "flex";
  });

  /* ================= DARK MODE ================= */
  themeToggle.addEventListener("click", () => {
    document.body.classList.toggle("dark");
    themeToggle.textContent =
      document.body.classList.contains("dark") ? "☀️" : "🌙";
  });

  /* ================= UI HELPERS ================= */
  function addMessage(text, sender) {
    const div = document.createElement("div");
    div.className = `message ${sender}`;
    div.innerHTML = sender === "bot" ? highlight(text) : text;
    chatBody.appendChild(div);
    chatBody.scrollTop = chatBody.scrollHeight;

    if (sender === "bot" && pingSound) {
      pingSound.currentTime = 0;
      pingSound.play();
    }
  }

  function showTyping() {
    const typing = document.createElement("div");
    typing.className = "message bot typing";
    typing.id = "typing-indicator";
    typing.textContent = `${BOT_NAME} is typing...`;
    chatBody.appendChild(typing);
    chatBody.scrollTop = chatBody.scrollHeight;
  }

  function hideTyping() {
    const typing = document.getElementById("typing-indicator");
    if (typing) typing.remove();
  }

  /* ================= WELCOME ================= */
  function welcomeMessage() {
    addMessage(
      `Hey 👋 I’m ${BOT_NAME}.  
I can explain this portfolio in detail — just ask!`,
      "bot"
    );
    addSuggestions();
  }

  /* ================= SUGGESTIONS ================= */
  function addSuggestions() {
    const box = document.createElement("div");
    box.className = "suggestions";
    box.innerHTML = `
      <button>🎓 Education</button>
      <button>💼 Experience</button>
      <button>🛠️ Skills</button>
      <button>🎨 Design</button>
      <button>🏆 Awards</button>
    `;
    chatBody.appendChild(box);
    chatBody.scrollTop = chatBody.scrollHeight;

    box.querySelectorAll("button").forEach(btn => {
      btn.onclick = () => {
        addMessage(btn.innerText, "user");
        box.remove();
        processBotReply(btn.innerText);
      };
    });
  }

  /* ================= BOT BRAIN ================= */
  function botReply(message) {
    const msg = message.toLowerCase();

    /* Creator */
    if (msg.includes("who made you") || msg.includes("creator")) {
      return "I was handcrafted by **Pushpak Kumar** ✨ to showcase clean UI, logic, and UX thinking.";
    }

    /* Resume / LinkedIn */
    if (msg.includes("resume")) {
      return "📄 You can find my resume on the main website section.";
    }

    if (msg.includes("linkedin")) {
      return "🔗 My LinkedIn profile is linked on this page.";
    }

    /* Explore More / Details */
    if (
      msg.includes("explore") ||
      msg.includes("more") ||
      msg.includes("details")
    ) {
      if (!lastTopic || !sectionCache[lastTopic]) {
        return "Tell me which section you want to explore 😊";
      }

      return `📌 Deep dive into **${lastTopic.toUpperCase()}**

${formatDetailed(sectionCache[lastTopic])}

Would you like:
⭐ Key highlights  
📌 Another section  
📄 Resume?`;
    }

    /* Key Highlights */
    if (msg.includes("highlight")) {
      if (!lastTopic || !sectionCache[lastTopic]) {
        return "Please open a section first 🙂";
      }

      return `⭐ Key highlights from **${lastTopic}**

${extractHighlights(sectionCache[lastTopic])}`;
    }

    /* Main section detection */
    const keywordMap = {
      education: { words: ["education", "degree", "college"], emoji: "🎓" },
      experience: { words: ["experience", "work", "articleship"], emoji: "💼" },
      skills: { words: ["skills", "technical"], emoji: "🛠️" },
      design: { words: ["design", "ui", "ux"], emoji: "🎨" },
      awards: { words: ["award", "achievement"], emoji: "🏆" }
    };

    for (const key in keywordMap) {
      if (keywordMap[key].words.some(w => msg.includes(w))) {
        lastTopic = key;

        const heading = document.querySelector(`[data-chat="${key}"]`);
        if (!heading) {
          return "That section isn’t available on this page yet.";
        }

        let content = "";
        let el = heading.nextElementSibling;

        while (el && !/^H[1-6]$/.test(el.tagName)) {
          content += el.innerText + " ";
          el = el.nextElementSibling;
        }

        content = content.trim();
        sectionCache[key] = content;

        return `${keywordMap[key].emoji} Here’s a quick overview 👇

${content.substring(0, 220)}...

👉 Want deeper details or highlights?`;
      }
    }

    /* Default fallback */
    if (lastTopic) {
      return `Want to explore **${lastTopic}** in more depth? 😊`;
    }

    return `You can ask me about:
🎓 Education  
💼 Experience  
🛠️ Skills  
🎨 Design  
🏆 Awards`;
  }

  function processBotReply(text) {
    showTyping();
    setTimeout(() => {
      hideTyping();
      addMessage(botReply(text), "bot");
      addFollowUps();
    }, 700);
  }

  /* ================= FOLLOW UPS ================= */
  function addFollowUps() {
    const follow = document.createElement("div");
    follow.className = "followups";
    follow.innerHTML = `
      <button>🔍 Explore more</button>
      <button>⭐ Key highlights</button>
      <button>📄 Resume</button>
      <button>🔗 LinkedIn</button>
    `;
    chatBody.appendChild(follow);
    chatBody.scrollTop = chatBody.scrollHeight;

    follow.querySelectorAll("button").forEach(btn => {
      btn.onclick = () => {
        addMessage(btn.innerText, "user");
        follow.remove();
        processBotReply(btn.innerText);
      };
    });
  }

  /* ================= FORMATTERS ================= */
  function formatDetailed(text) {
    return text
      .split(".")
      .map(l => l.trim())
      .filter(l => l.length > 30)
      .slice(0, 6)
      .map(l => "• " + l + ".")
      .join("\n");
  }

  function extractHighlights(text) {
    return text
      .split(".")
      .filter(l => l.length > 40)
      .slice(0, 4)
      .map(l => "✔️ " + l.trim() + ".")
      .join("\n");
  }

  function highlight(text) {
    return text
      .replace(/education/gi, "<b>education</b>")
      .replace(/experience/gi, "<b>experience</b>")
      .replace(/skills/gi, "<b>skills</b>");
  }

  /* ================= SEND ================= */
  chatSend.addEventListener("click", sendMessage);
  chatInput.addEventListener("keypress", e => {
    if (e.key === "Enter") sendMessage();
  });

  function sendMessage() {
    const text = chatInput.value.trim();
    if (!text) return;

    addMessage(text, "user");
    chatInput.value = "";
    processBotReply(text);
  }
});
